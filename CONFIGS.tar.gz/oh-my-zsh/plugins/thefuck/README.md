# The Fuck

[The Fuck](https://github.com/nvbn/thefuck) plugin — magnificent app which corrects your previous console command.

To use it, add thefuck to the plugins array of your zshrc file:

plugins=(... thefuck)

## Usage
Press `ESC` twice to correct previous console command.

## Notes
`Esc`-`Esc` key binding conflicts with [sudo](https://github.com/ohmyzsh/ohmyzsh/tree/master/plugins/sudo) plugin.
